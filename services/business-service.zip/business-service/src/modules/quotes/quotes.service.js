import { AppError } from "../../common/errors/app-error.js";
import { fulfillmentClient } from "../../common/http/fulfillment-client.js";
import { leadsRepository } from "../leads/leads.repository.js";
import { vendorsRepository } from "../vendors/vendors.repository.js";
import { quotesRepository } from "./quotes.repository.js";
import { logger } from "../../common/utils/logger.js";
import mongoose from "mongoose";

async function attachLeads(quotes) {
  const leadIds = [
    ...new Set(quotes.map((quote) => quote.leadId?.toString()).filter(Boolean)),
  ];
  const leads = leadIds.length
    ? await leadsRepository.findLeadsByIds(leadIds)
    : [];
  const leadById = new Map(
    leads.map((lead) => [String(lead.id || lead._id), lead]),
  );

  return quotes.map((quote) => ({
    ...quote,
    lead: leadById.get(String(quote.leadId)) ?? null,
  }));
}

export const quotesService = {
  async createQuote(user, leadId, input) {
    if (user.role !== "vendor" && user.role !== "admin") {
      throw new AppError(403, "Only vendors can submit quotes");
    }

    if (user.role === "vendor") {
      const vendorProfile = await vendorsRepository.findByVendorId(user.userId);

      if (vendorProfile?.verificationStatus !== "verified") {
        throw new AppError(403, "Vendor account is waiting for admin approval");
      }
    }

    if (!mongoose.isValidObjectId(leadId)) {
      throw new AppError(400, "Invalid lead id");
    }

    const lead = await leadsRepository.findLeadById(leadId);

    if (!lead) {
      throw new AppError(404, "Lead not found");
    }

    if (
      user.role === "vendor" &&
      !lead.assignedVendorIds?.includes(user.userId)
    ) {
      throw new AppError(403, "You are not assigned to this lead");
    }

    if (!["vendors_assigned", "open_for_quotes"].includes(lead.status)) {
      throw new AppError(409, "This lead is not open for bidding");
    }

    if (
      lead.biddingEndsAt &&
      new Date(lead.biddingEndsAt).getTime() < Date.now()
    ) {
      await leadsRepository.updateStatus(leadId, "closed");
      throw new AppError(409, "The bidding window for this lead has ended");
    }

    const totalPrice = Number(input.pricing?.totalPrice || 0);
    const minBid = Number(lead.bidRange?.minAmount || 0);
    const maxBid = Number(lead.bidRange?.maxAmount || 0);
    if (
      minBid > 0 &&
      maxBid > 0 &&
      (totalPrice < minBid || totalPrice > maxBid)
    ) {
      throw new AppError(
        400,
        `Quote price must be between ₹${minBid.toLocaleString("en-IN")} and ₹${maxBid.toLocaleString("en-IN")}`,
      );
    }

    const existingQuote = await quotesRepository.findQuoteByVendorAndLead(
      user.userId,
      leadId,
    );

    if (existingQuote) {
      if (existingQuote.status === "accepted") {
        throw new AppError(409, "Accepted quotes cannot be changed");
      }

      const quote = await quotesRepository.updateQuoteByVendorAndLead(user.userId, leadId, {
        ...input,
        customerId: lead.customerId,
      });

      if (lead.status === "vendors_assigned") {
        await leadsRepository.markOpenForQuotes(leadId);
      }

      return quote;
    }

    const quote = await quotesRepository.createQuote({
      ...input,
      leadId,
      customerId: lead.customerId,
      vendorId: user.userId,
      vendorEmail: user.email,
      status: "submitted",
      submittedAt: new Date(),
    });

    await leadsRepository.markOpenForQuotes(leadId);

    return quote;
  },

  async listQuotes(user, leadId = null) {
    if (leadId) {
      if (!mongoose.isValidObjectId(leadId)) {
        throw new AppError(400, "Invalid lead id");
      }

      const lead = await leadsRepository.findLeadById(leadId);

      if (!lead) {
        throw new AppError(404, "Lead not found");
      }

      const canView =
        user.role === "admin" ||
        (user.role === "vendor" &&
          (lead.assignedVendorIds?.includes(user.userId) ||
            lead.createdByVendorId === user.userId)) ||
        lead.customerId === user.userId;

      if (!canView) {
        throw new AppError(403, "You do not have access to these quotes");
      }

      return attachLeads(await quotesRepository.findQuotesByLeadId(leadId));
    }

    if (user.role === "vendor") {
      const vendorProfile = await vendorsRepository.findByVendorId(user.userId);

      if (vendorProfile?.verificationStatus !== "verified") {
        throw new AppError(403, "Vendor account is waiting for admin approval");
      }

      return attachLeads(
        await quotesRepository.findQuotesByVendor(user.userId),
      );
    }

    if (user.role === "admin") {
      return attachLeads(await quotesRepository.findAll());
    }

    const leads = await leadsRepository.findLeadsForCustomer(user.userId);
    const leadIds = leads.map((lead) => lead._id || lead.id).filter(Boolean);
    return attachLeads(
      await quotesRepository.findQuotesByCustomer(user.userId, leadIds),
    );
  },

  async getQuote(user, quoteId) {
    if (!mongoose.isValidObjectId(quoteId)) {
      throw new AppError(400, "Invalid quote id");
    }

    const quote = await quotesRepository.findQuoteById(quoteId);

    if (!quote) {
      throw new AppError(404, "Quote not found");
    }

    const lead = await leadsRepository.findLeadById(quote.leadId);

    if (!lead) {
      throw new AppError(404, "Lead not found");
    }

    const canView =
      user.role === "admin" ||
      quote.vendorId === user.userId ||
      lead.customerId === user.userId;

    if (!canView) {
      throw new AppError(403, "You do not have access to this quote");
    }

    return quote;
  },

  async acceptQuote(user, quoteId, authorization) {
    if (user.role !== "customer" && user.role !== "admin") {
      throw new AppError(403, "Only customers can select a vendor");
    }

    if (!mongoose.isValidObjectId(quoteId)) {
      throw new AppError(400, "Invalid quote id");
    }

    const quote = await quotesRepository.findQuoteById(quoteId);

    if (!quote) {
      throw new AppError(404, "Quote not found");
    }

    if (quote.status === "withdrawn") {
      throw new AppError(409, "This quote is no longer available");
    }

    const lead = await leadsRepository.findLeadById(quote.leadId);

    if (!lead) {
      throw new AppError(404, "Lead not found");
    }

    const canSelect = user.role === "admin" || lead.customerId === user.userId;

    if (!canSelect) {
      throw new AppError(
        403,
        "You can only select vendors for your own bookings",
      );
    }

    if (
      lead.biddingEndsAt &&
      !["quote_selected", "closed"].includes(lead.status) &&
      new Date(lead.biddingEndsAt).getTime() <= Date.now()
    ) {
      await leadsRepository.updateStatus(quote.leadId, "closed");
      throw new AppError(
        409,
        "The 48-hour bidding window for this booking has ended. Please create a new booking to restart bidding.",
      );
    }

    if (
      lead.status === "quote_selected" &&
      lead.selection?.quoteId?.toString() !== quoteId
    ) {
      throw new AppError(
        409,
        "A vendor has already been selected for this booking",
      );
    }

    // If this exact quote is already accepted and lead already selected, return existing state
    if (
      quote.status === "accepted" &&
      lead.status === "quote_selected" &&
      lead.selection?.quoteId?.toString() === quoteId
    ) {
      const project = await fulfillmentClient.createProjectFromAcceptedQuote({
        lead,
        quote,
        authorization,
      });
      return { quote, lead, project };
    }

    const acceptedQuote = await quotesRepository.acceptQuote(
      quoteId,
      quote.leadId,
    );
    const selectedLead = await leadsRepository.markQuoteSelected(quote.leadId, {
      quoteId,
      vendorId: quote.vendorId,
      selectedAt: new Date(),
    });

    let project;
    try {
      project = await fulfillmentClient.createProjectFromAcceptedQuote({
        lead: selectedLead,
        quote: acceptedQuote,
        authorization,
      });
    } catch (fulfillmentError) {
      // Rollback: revert quote and lead to their pre-acceptance state so the
      // admin/customer can safely retry without the system being left inconsistent.
      logger.error(
        "Project creation failed after quote acceptance — rolling back",
        {
          quoteId,
          leadId: quote.leadId?.toString(),
          error: fulfillmentError.message,
        },
      );
      await Promise.allSettled([
        quotesRepository.revertQuoteAcceptance(quoteId),
        leadsRepository.revertQuoteSelection(quote.leadId),
      ]);
      throw fulfillmentError;
    }

    return {
      quote: acceptedQuote,
      lead: selectedLead,
      project,
    };
  },
};
