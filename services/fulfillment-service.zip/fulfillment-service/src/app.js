import cors from "cors";
import express from "express";
import helmet from "helmet";
import path from "node:path";
import {
  getDatabaseHealth,
} from "./common/database/database-health.js";
import { errorHandler } from "./common/middleware/error-handler.js";
import { notFoundHandler } from "./common/middleware/not-found-handler.js";
import { requestContext } from "./common/middleware/request-context.js";
import { env } from "./config/env.js";
import { apiRouter } from "./routes/index.js";

export function createApp() {
  const app = express();

  app.disable("x-powered-by");
  app.set("trust proxy", env.nodeEnv === "production" ? 1 : false);
  app.use(helmet());
  app.use(
    cors({
      origin: env.clientUrl,
      credentials: true,
    }),
  );
  app.use(express.json({ limit: "7mb" }));
  app.use(express.urlencoded({ extended: true }));
  app.use(requestContext);
  app.use("/uploads", express.static(path.resolve("uploads")));

  app.get("/health", (req, res) => {
    const database = getDatabaseHealth();
    res.status(database.status === "ok" ? 200 : 503).json({
      service: env.serviceName,
      status: database.status === "ok" ? "ok" : "degraded",
      database,
      requestId: req.requestId,
      timestamp: new Date().toISOString(),
    });
  });

  app.use("/api/v1", apiRouter);
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
